package modelo;

public interface Pago {
    double calcularTotal();
}
