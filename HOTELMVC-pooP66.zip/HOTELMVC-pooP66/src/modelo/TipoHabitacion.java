package modelo;

public enum TipoHabitacion {
    PENTHOUSE,
    DELUXE,
    SUITE_EJECUTIVA,
    SUITE,
    FAMILIAR,
    TRIPLE,
    DOBLE,
    INDIVIDUAL,
    ECONOMICA
}
